# App packages
# PRIlib = "Y:/AG_Baumgrass/AG-PRI/R/R-3.5.3/library"
PRIlib = "Y:/AG_Baumgrass/AG-PRI/R/R-3.6.1/library"

library(shiny, lib.loc = PRIlib)
library(shinydashboard, lib.loc = PRIlib)
library(shinyjs, lib.loc = PRIlib)
library(V8, lib.loc = PRIlib)
library(shinyBS, lib.loc = PRIlib)
library(RSQLite, lib.loc = PRIlib)
library(rChoiceDialogs, lib.loc = PRIlib)
library(rJava,quietly=TRUE)
library(flowCore, lib.loc = PRIlib)
# For digest(). Calculates unique ID for files.
library(digest, lib.loc = PRIlib)
# To bind dataframes with unequal columns.
library(gtools, lib.loc = PRIlib)
# To edit character vectors.
library(stringr, lib.loc = PRIlib)
library(RISmed, lib.loc = PRIlib)
library(httpuv, lib.loc = PRIlib)

# private packages
library(cytobank, lib.loc = PRIlib)
# library(needfulFuns)
# quietly = TRUE, warn.conflicts = FALSE,

### SHINY NEEDS TO BE VERSION 1.3.2 TO WORK!!!
# packageurl="https://cran.r-project.org/src/contrib/Archive/shiny/shiny_1.3.2.tar.gz"
# install.packages(packageurl, dependencies=T, repos=NULL, type="source",lib = PRIlib)
# BiocManager::install("FlowRepositoryR",lib = PRIlib)

# BiocManager::install(c("shinydashboard","shinyjs","V8","shinyBS","rJava","RISmed",
#                        "rChoiceDialogs","RSQLite","flowCore","digest","gtools","stringr",
#                        "tcltk2","R.devices","httr","devtools","roxygen2","DT","R.devices"))
# BiocManager::install(c("devtools","XML","rvest"))
# install.packages("Y:/AG_Baumgrass/AG-PRI/R/private_packages/needfulFuns_1.2/needfulFuns/",
#                  repos=NULL,type="source")
# install.packages("Y:/AG_Baumgrass/AG-PRI/R/private_packages/cytobank_1.3/cytobank/",
#                  repos=NULL,type="source")
