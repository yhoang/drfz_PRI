rm(list=ls())

# set working directory
setwd("Y:/AG_Baumgrass/AG-PRI/PRIbase")

# set paths for app and databases
App.path="Y:/AG_Baumgrass/AG-PRI/PRIbase/App20200217/"
DB.path="Y:/AG_Baumgrass/AG-PRI//DB/"
FlowRepDb.path="Y:/AG_Baumgrass/AG-PRI/PRIbase/App20200217/www/FlowRep_Experiments.sqlite3"
FCS.download.path="Y:/AG_Baumgrass/AG-PRI/PRIbase/FCS"

# Loads all needed packages.
source("App20200217/www/packages.R")

# Starts App.
runApp("App20200217/")
