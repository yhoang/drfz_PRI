#usr/bin/R
PRIlib = "Y:/AG_Baumgrass/AG-PRI/R/R-3.6.1/library"

###  PRI-ana
install.packages("RSQLite",lib = PRIlib)
install.packages("tcltk2",lib = PRIlib)
install.packages("R.devices",lib = PRIlib)

### PRI-base public packages -------------------------------------------------------------
# SHINY NEEDS TO BE VERSION 1.3.2 TO WORK!!!
packageurl="https://cran.r-project.org/src/contrib/Archive/shiny/shiny_1.3.2.tar.gz"
install.packages(packageurl, dependencies=T, repos=NULL, type="source",lib = PRIlib)

# these are not available on CRAN
BiocManager::install("flowCore",lib = PRIlib)
BiocManager::install("FlowRepositoryR",lib = PRIlib)
BiocManager::install(c("devtools","XML","rvest"),lib = PRIlib)

install.packages(c("shinydashboard","shinyjs","V8","shinyBS","rJava","rvest",
                   "XML","xml2","RISmed","rChoiceDialogs","digest","gtools","stringr",
                   "httr","devtools","roxygen2","DT","xlsx"),lib = PRIlib)

### PRI-base private packages -------------------------------------------------------------
install.packages("Y:/AG_Baumgrass/AG-PRI/R/private_packages/needfulFuns_1.3/needfulFuns/",repos=NULL,type="source",lib = PRIlib)
install.packages("Y:/AG_Baumgrass/AG-PRI/R/private_packages/cytobank_1.3/cytobank/",repos=NULL,type="source",lib = PRIlib)

